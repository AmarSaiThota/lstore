class Index:
    def __init__(self, table):
        self.table = table
        # indices[c] = dict mapping value -> set of RIDs, or None if dropped
        self.indices = [dict() for _ in range(table.num_columns)]

    def create_index(self, column_number):
        """Build an index on the given column by scanning all existing records."""
        from lstore.config import NUM_META_COLUMNS
        self.indices[column_number] = {}
        for rid, (pr_id, is_tail, pg, idx) in self.table.page_directory.items():
            if is_tail != 0:
                continue
            pr = self.table.page_ranges[pr_id]
            val = pr.base_page_sets[pg].pages[NUM_META_COLUMNS + column_number].read(idx)
            if val not in self.indices[column_number]:
                self.indices[column_number][val] = set()
            self.indices[column_number][val].add(rid)

    def drop_index(self, column_number):
        """Drop the index on the given column. Locate will fall back to scan."""
        self.indices[column_number] = None

    def add(self, column, value, base_rid):
        d = self.indices[column]
        if d is None:
            return  # index dropped, skip
        if value not in d:
            d[value] = set()
        d[value].add(base_rid)

    def remove(self, column, value, base_rid):
        d = self.indices[column]
        if d is None:
            return  # index dropped, skip
        if value in d:
            d[value].discard(base_rid)
            if not d[value]:
                del d[value]

    def locate(self, column, value):
        d = self.indices[column]
        if d is not None:
            return list(d.get(value, set()))
        # Fallback: scan all base records
        return self._scan_column(column, value)

    def locate_range(self, begin, end, column):
        d = self.indices[column]
        if d is not None:
            out = []
            for v, rset in d.items():
                if begin <= v <= end:
                    out.extend(rset)
            return out
        # Fallback: scan all base records
        return self._scan_range(column, begin, end)

    def _scan_column(self, column, value):
        """Full table scan for a single value when no index exists."""
        from lstore.config import NUM_META_COLUMNS
        out = []
        for rid, (pr_id, is_tail, pg, idx) in self.table.page_directory.items():
            if is_tail != 0:
                continue
            pr = self.table.page_ranges[pr_id]
            val = pr.base_page_sets[pg].pages[NUM_META_COLUMNS + column].read(idx)
            if val == value:
                out.append(rid)
        return out

    def _scan_range(self, column, begin, end):
        """Full table scan for a range when no index exists."""
        from lstore.config import NUM_META_COLUMNS
        out = []
        for rid, (pr_id, is_tail, pg, idx) in self.table.page_directory.items():
            if is_tail != 0:
                continue
            pr = self.table.page_ranges[pr_id]
            val = pr.base_page_sets[pg].pages[NUM_META_COLUMNS + column].read(idx)
            if begin <= val <= end:
                out.append(rid)
        return out

